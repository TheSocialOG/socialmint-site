export default function Home() {
  return (
    <main style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>Social Mint ($SMNT)</h1>
      <p>Tu crées. Tu gagnes. Tu deviens ta propre banque.</p>
    </main>
  );
}
